import React from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { DecorativeBar } from './DecorativeBar';

export function LanguageSwitch() {
  const { language, setLanguage } = useLanguage();

  return (
    <div className="fixed top-4 right-4 z-50">
      <div className="glass-card rounded-xl p-1 flex gap-1">
        <button
          onClick={() => setLanguage('fr')}
          className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${
            language === 'fr'
              ? 'bg-purple-500 text-white'
              : 'hover:bg-purple-50 text-gray-600'
          }`}
        >
          FR
        </button>
        <button
          onClick={() => setLanguage('en')}
          className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${
            language === 'en'
              ? 'bg-purple-500 text-white'
              : 'hover:bg-purple-50 text-gray-600'
          }`}
        >
          EN
        </button>
      </div>
      <DecorativeBar className="mt-1" />
    </div>
  );
}