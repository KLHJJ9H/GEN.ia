import React from 'react';
import { RefreshCw, Download } from 'lucide-react';
import { cn } from '../lib/utils';
import { useLanguage } from '../contexts/LanguageContext';

interface ThumbnailGridProps {
  thumbnails: string[];
  onRegenerate: () => void;
  onSelect: (index: number) => void;
  loading?: boolean;
}

export function ThumbnailGrid({ thumbnails, onRegenerate, onSelect, loading = false }: ThumbnailGridProps) {
  const { t } = useLanguage();

  if (loading) {
    return (
      <div className="w-full flex items-center justify-center py-16">
        <div className="text-center space-y-4">
          <RefreshCw className="h-10 w-10 text-purple-500 animate-spin mx-auto" />
          <p className="text-gray-600">{t('loading')}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {thumbnails.map((thumbnail, index) => (
          <div
            key={index}
            className="group relative rounded-xl overflow-hidden shadow-lg transition-all duration-300 hover:shadow-2xl"
            onClick={() => onSelect(index)}
          >
            <img
              src={thumbnail}
              alt={`${t('version')} ${index + 1}`}
              className="w-full aspect-video object-cover transition-transform duration-300 group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-purple-900/60 via-purple-500/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
              <div className="absolute bottom-0 left-0 right-0 p-4 flex items-center justify-between">
                <span className="text-white text-sm font-medium">
                  {t('version')} {index + 1}
                </span>
                <Download className="h-5 w-5 text-white" />
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="flex justify-center">
        <button
          onClick={onRegenerate}
          className="btn-secondary inline-flex items-center gap-2"
        >
          <RefreshCw className="h-5 w-5" />
          {t('regenerateButton')}
        </button>
      </div>
    </div>
  );
}